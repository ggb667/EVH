import json
import os
from datetime import datetime, timezone
from pathlib import Path

import boto3

from scripts.gmail.daily_email_summary import (
    DEFAULT_DAILY_SUMMARY_RECIPIENT,
    DEFAULT_OPENAI_MODEL,
    EXPECTED_MAILBOX_EMAIL,
    build_dry_run_result,
    build_email_message,
    build_summary_prompt,
    checkpoint_parameter_for_mailbox,
    extract_response_text,
    load_messages,
    load_sent_messages,
    load_client_config,
    parse_summary_result,
    render_markdown,
    reconcile_summary_result,
    SentItem,
    refresh_token,
    Token,
    verify_expected_mailbox,
    _openai_responses_completion,
)
from scripts.gmail.evhstaff_gmail_inventory import gmail_send_message

SECRETS_CLIENT = boto3.client("secretsmanager")
PARAMETER_CLIENT = boto3.client("ssm")


def load_oauth_secret(secret_arn: str) -> dict:
    response = SECRETS_CLIENT.get_secret_value(SecretId=secret_arn)
    secret_string = response.get("SecretString", "")
    if not secret_string:
        raise RuntimeError("Secrets Manager returned an empty secret string.")
    secret = json.loads(secret_string)
    if not isinstance(secret, dict):
        raise RuntimeError("OAuth secret must be a JSON object.")
    return secret


def load_accounts() -> list[dict]:
    raw = os.environ.get("DAILY_SUMMARY_ACCOUNTS_JSON", "")
    if not raw.strip():
        return []
    accounts = json.loads(raw)
    if not isinstance(accounts, list):
        raise RuntimeError("DAILY_SUMMARY_ACCOUNTS_JSON must be a JSON array.")
    result = []
    for account in accounts:
        if not isinstance(account, dict):
            continue
        mailbox_email = str(account.get("mailbox_email", "")).strip().lower()
        if not mailbox_email:
            continue
        result.append(account)
    return result


def sanitize_mailbox_key(mailbox_email: str) -> str:
    return mailbox_email.strip().lower().replace("@", "_").replace(".", "_")


def mailbox_checkpoint_parameter(mailbox_email: str) -> str:
    return f"/evh/daily-summary/{sanitize_mailbox_key(mailbox_email)}/last_successful_run"


def find_account(mailbox_email: str, accounts: list[dict]) -> dict:
    mailbox_email = mailbox_email.strip().lower()
    for account in accounts:
        if str(account.get("mailbox_email", "")).strip().lower() == mailbox_email:
            return account
    return {}


def load_checkpoint(parameter_name: str) -> str | None:
    try:
        response = PARAMETER_CLIENT.get_parameter(Name=parameter_name)
    except Exception:
        return None
    value = response.get("Parameter", {}).get("Value", "")
    return value if isinstance(value, str) and value.strip() else None


def save_checkpoint(parameter_name: str) -> None:
    PARAMETER_CLIENT.put_parameter(
        Name=parameter_name,
        Value=datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        Type="String",
        Overwrite=True,
    )


def apply_checkpoint(query: str, checkpoint_value: str | None) -> str:
    if not checkpoint_value:
        return query
    date_part = checkpoint_value[:10]
    query = query.strip()
    prefix = f"after:{date_part.replace('-', '/')}"
    return f"{prefix} {query}".strip() if query else prefix


def lambda_handler(event, context):
    accounts = load_accounts()
    mailbox_email = os.environ.get("EXPECTED_MAILBOX_EMAIL", EXPECTED_MAILBOX_EMAIL).strip().lower()
    account = find_account(mailbox_email, accounts)

    secret_arn = account.get("oauth_secret_arn") if account else os.environ.get("GMAIL_OAUTH_SECRET_ARN", "")
    if not secret_arn:
        raise RuntimeError(f"No OAuth secret ARN configured for mailbox {mailbox_email!r}.")
    oauth = load_oauth_secret(str(secret_arn))

    to_addr = account.get("daily_summary_to") if account else os.environ.get("DAILY_SUMMARY_TO", DEFAULT_DAILY_SUMMARY_RECIPIENT)
    checkpoint_param = account.get("checkpoint_parameter") if account else os.environ.get("DAILY_SUMMARY_CHECKPOINT_PARAMETER") or checkpoint_parameter_for_mailbox(mailbox_email)
    checkpoint_param = str(checkpoint_param)

    client_json = {
        "installed": {
            "client_id": oauth["client_id"],
            "client_secret": oauth["client_secret"],
            "token_uri": "https://oauth2.googleapis.com/token",
            "auth_uri": "https://accounts.google.com/o/oauth2/auth",
            "redirect_uris": ["http://localhost"],
        }
    }
    client_path = Path("/tmp/gmail_client.json")
    client_path.write_text(json.dumps(client_json), encoding="utf-8")
    client = load_client_config(client_path)

    token_path = Path("/tmp/evhstaff_gmail_token.json")
    if token_path.exists():
        token = Token.from_file(token_path)
    else:
        token = Token(access_token="", refresh_token=oauth["refresh_token"], token_type="Bearer", expires_at=0, scope="https://mail.google.com/")
    if token.expired():
        token = refresh_token(client, token)
        token_path.write_text(json.dumps(token.dump(), indent=2, sort_keys=True), encoding="utf-8")

    verify_expected_mailbox(token, client, mailbox_email)

    checkpoint_value = load_checkpoint(checkpoint_param)
    query = apply_checkpoint(os.environ.get("DAILY_SUMMARY_QUERY", "newer_than:1d"), checkpoint_value)
    sent_query = apply_checkpoint(os.environ.get("DAILY_SUMMARY_SENT_QUERY", "in:sent newer_than:1d"), checkpoint_value)
    max_results = int(os.environ.get("DAILY_SUMMARY_MAX_RESULTS", "30"))
    model = os.environ.get("OPENAI_MODEL", DEFAULT_OPENAI_MODEL)
    send_email = os.environ.get("DAILY_SUMMARY_SEND_EMAIL", "true").lower() in ("1", "true", "yes", "y")

    items = load_messages(token, query, max_results)
    sent_items = [
        {
            "message_id": item.message_id,
            "thread_id": item.thread_id,
            "recipients": item.recipients,
            "subject": item.subject,
            "body_text": item.body_text,
        }
        for item in load_sent_messages(token, sent_query, max_results)
    ]

    if not items:
        rendered = "# Communication Summary\n\nNo messages matched the query.\n"
        return {"statusCode": 200, "body": json.dumps({"message": "No messages matched the query.", "summary": rendered, "count": 0})}

    if event.get("dry_run", False):
        result = build_dry_run_result(items, query)
    else:
        api_key = os.environ["OPENAI_API_KEY"]
        messages = build_summary_prompt(items, query)
        response = _openai_responses_completion(api_key, model, messages)
        content = extract_response_text(response)
        if not content:
            raise RuntimeError("OpenAI returned empty content.")
        result = parse_summary_result(content)

    sent_records = [
        SentItem(
            message_id=str(item.get("message_id", "")),
            thread_id=str(item.get("thread_id", "")),
            recipients=str(item.get("recipients", "")),
            subject=str(item.get("subject", "")),
            body_text=str(item.get("body_text", "")),
        )
        for item in sent_items
    ]
    result = reconcile_summary_result(result, items, sent_records)
    result["sent_today"] = sent_items
    rendered = render_markdown(result, query, len(items))
    Path("/tmp/evh_daily_email_summary.md").write_text(rendered, encoding="utf-8")
    Path("/tmp/evh_daily_email_summary.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    sent_result = None
    if send_email and not event.get("dry_run", False):
        raw_message = build_email_message("Daily Communication Summary", rendered, from_addr=mailbox_email, to_addrs=[to_addr])
        sent_result = gmail_send_message(token, raw_message)

    if not event.get("dry_run", False):
        save_checkpoint(checkpoint_param)

    return {"statusCode": 200, "body": json.dumps({"message": "Daily summary completed.", "sent_email": bool(sent_result), "sent_result": sent_result, "query": query, "count": len(items)})}
