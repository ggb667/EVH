import json
import os
from pathlib import Path

import boto3

from scripts.gmail.daily_email_summary import (
    DEFAULT_DAILY_SUMMARY_RECIPIENT,
    DEFAULT_OPENAI_MODEL,
    EXPECTED_MAILBOX_EMAIL,
    build_dry_run_result,
    build_email_message,
    build_summary_prompt,
    extract_response_text,
    load_messages,
    load_sent_messages,
    load_client_config,
    parse_summary_result,
    render_markdown,
    refresh_token,
    Token,
    verify_expected_mailbox,
    _openai_responses_completion,
)
from scripts.gmail.evhstaff_gmail_inventory import gmail_send_message

SECRETS_CLIENT = boto3.client("secretsmanager")


def load_oauth_secret(secret_arn: str) -> dict:
    response = SECRETS_CLIENT.get_secret_value(SecretId=secret_arn)
    secret_string = response.get("SecretString", "")
    if not secret_string:
        raise RuntimeError("Secrets Manager returned an empty secret string.")
    secret = json.loads(secret_string)
    if not isinstance(secret, dict):
        raise RuntimeError("OAuth secret must be a JSON object.")
    return secret


def lambda_handler(event, context):
    secret_arn = os.environ["GMAIL_OAUTH_SECRET_ARN"]
    oauth = load_oauth_secret(secret_arn)

    client_json = {
        "installed": {
            "client_id": oauth["client_id"],
            "client_secret": oauth["client_secret"],
            "token_uri": "https://oauth2.googleapis.com/token",
            "auth_uri": "https://accounts.google.com/o/oauth2/auth",
            "redirect_uris": ["http://localhost"],
        }
    }
    client_path = Path("/tmp/gmail_client.json")
    client_path.write_text(json.dumps(client_json), encoding="utf-8")
    client = load_client_config(client_path)

    token = Token.from_file(Path("/tmp/evhstaff_gmail_token.json")) if Path("/tmp/evhstaff_gmail_token.json").exists() else Token(access_token="", refresh_token=oauth["refresh_token"], token_type="Bearer", expires_at=0, scope="https://mail.google.com/")
    if token.expired():
        token = refresh_token(client, token)

    verify_expected_mailbox(token, client)

    query = os.environ.get("DAILY_SUMMARY_QUERY", "newer_than:1d")
    sent_query = os.environ.get("DAILY_SUMMARY_SENT_QUERY", "in:sent newer_than:1d")
    max_results = int(os.environ.get("DAILY_SUMMARY_MAX_RESULTS", "30"))
    model = os.environ.get("OPENAI_MODEL", DEFAULT_OPENAI_MODEL)
    send_email = os.environ.get("DAILY_SUMMARY_SEND_EMAIL", "true").lower() in ("1", "true", "yes", "y")
    to_addr = os.environ.get("DAILY_SUMMARY_TO", DEFAULT_DAILY_SUMMARY_RECIPIENT)

    items = load_messages(token, query, max_results)
    sent_items = [
        {"message_id": item.message_id, "recipients": item.recipients, "subject": item.subject}
        for item in load_sent_messages(token, sent_query, max_results)
    ]

    if not items:
        rendered = "# Communication Summary\n\nNo unread messages matched the query.\n"
        return {"statusCode": 200, "body": json.dumps({"message": "No unread messages matched the query.", "summary": rendered, "count": 0})}

    if event.get("dry_run", False):
        result = build_dry_run_result(items, query)
    else:
        api_key = os.environ["OPENAI_API_KEY"]
        messages = build_summary_prompt(items, query)
        response = _openai_responses_completion(api_key, model, messages)
        content = extract_response_text(response)
        if not content:
            raise RuntimeError("OpenAI returned empty content.")
        result = parse_summary_result(content)

    result["sent_today"] = sent_items
    rendered = render_markdown(result, query, len(items))
    Path("/tmp/evh_daily_email_summary.md").write_text(rendered, encoding="utf-8")
    Path("/tmp/evh_daily_email_summary.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    sent_result = None
    if send_email and not event.get("dry_run", False):
        raw_message = build_email_message("Daily Communication Summary", rendered, from_addr=EXPECTED_MAILBOX_EMAIL, to_addrs=[to_addr])
        sent_result = gmail_send_message(token, raw_message)

    return {"statusCode": 200, "body": json.dumps({"message": "Daily summary completed.", "sent_email": bool(sent_result), "sent_result": sent_result, "query": query, "count": len(items)})}
